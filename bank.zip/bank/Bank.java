package bank;

import java.util.HashSet;

public class Bank {
    private HashSet<Object> users;

    public Bank() {
        this.users = new HashSet<>();
    }

    public void addUser(Object user) {
        users.add(user);
    }

    private static TestFrancesco francescoUser = new TestFrancesco(10000);
    private static TestMario marioUser = new TestMario(50);


    public static void main(String[] args) throws Exception {
        Bank bank = new Bank();
        bank.addUser(francescoUser);
        bank.addUser(marioUser);



        francescoUser.printBalance();
        francescoUser.addBalance(500);
        francescoUser.printBalance();
        francescoUser.subtractBalance(200);
        francescoUser.printBalance();

        marioUser.printBalance();
        marioUser.addBalance(100);
        marioUser.printBalance();

        francescoUser.calculateInterests(20);
    }   
    
}
